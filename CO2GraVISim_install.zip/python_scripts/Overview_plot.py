# Overview_plot.py
# This script produces plots from the output of CO2GraVISim,
# showing
# - the Permeability and Porosity fields,
# - the ceiling topography,
# - the local thickness and volumes of the mobile and trapped CO2
# - the pressure fields for the CO2 and the ambient fluid
# - the total volumes of free and trapped CO2 over time

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib import cm
from matplotlib import colors
from matplotlib.ticker import FuncFormatter
from matplotlib.gridspec import GridSpec
import warnings

# load plot times
plot_times = np.loadtxt("./Output/Other/plot_times.txt")


# load parameter values
parameters = np.loadtxt(
    "./Output/Other/parameter_values.txt"
)  # nx ny dx dy M Gamma_val, s_c_r, s_a_i, C_sat, q_dissolve
nx = int(parameters[0])
ny = int(parameters[1])
dx = parameters[2]
dy = parameters[3]

M           = parameters[4]
Gamma_val   = parameters[5]
s_c_r       = parameters[6]
s_a_i       = parameters[7]
C_sat       = parameters[8]
q_dissolve  = parameters[9]


# Spatial grids
X_grid = np.arange(-(nx - 1) / 2.0, (nx - 1) / 2.0 + 1.0) * dx
Y_grid = np.arange(-(ny - 1) / 2.0, (ny - 1) / 2.0 + 1.0) * dy

X, Y = np.meshgrid(X_grid, Y_grid)


# load injection locations
inj_locs_data = np.loadtxt("./Output/Other/injection_locations.txt")

if np.ndim(inj_locs_data) == 1:
    # If there's only one injection point, this needs to be done slightly differently
    n_inj_locs = 1
    inj_grid_vals = np.zeros((1, 2))
    inj_grid_vals[0, 0] = X_grid[int(inj_locs_data[0])]
    inj_grid_vals[0, 1] = Y_grid[int(inj_locs_data[1])]
else:
    shape_inj_locs = np.shape(inj_locs_data)
    n_inj_locs = shape_inj_locs[0]
    inj_grid_vals = np.zeros((n_inj_locs, 2))
    for k in range(0, n_inj_locs):
        inj_grid_vals[k, 0] = X_grid[int(inj_locs_data[k, 0])]
        inj_grid_vals[k, 1] = Y_grid[int(inj_locs_data[k, 1])]


# Mesh coarsening for vector flow field plots
flow_field_step = 5


# Reservoir Ceiling and Basement topography
H0 = np.loadtxt("./Input/ceil_topo.txt")
B0 = np.loadtxt("./Input/base_topo.txt")

# Porosity and Permeability fields
Porosity = np.loadtxt("./Input/porosity.txt")
Permeability = np.loadtxt("./Input/permeability.txt")


## Load plot data into arrays
# Free and trapped CO2 thicknesses
h_array     = np.zeros([np.shape(H0)[0], np.shape(H0)[1], len(plot_times)])
h_res_array = np.zeros([np.shape(H0)[0], np.shape(H0)[1], len(plot_times)])

# Free and trapped CO2 local volumes
V_active_array  = np.zeros([np.shape(H0)[0], np.shape(H0)[1], len(plot_times)])
V_trapped_array = np.zeros([np.shape(H0)[0], np.shape(H0)[1], len(plot_times)])

# Pressure fields for the CO2 and ambient
P_amb_array = np.zeros([np.shape(H0)[0], np.shape(H0)[1], len(plot_times)])
P_cur_array = np.zeros([np.shape(H0)[0], np.shape(H0)[1], len(plot_times)])

# Pressure gradients for the ambient fluid
dPdx_amb_array = np.zeros([np.shape(X)[0], np.shape(X)[1], len(plot_times)])
dPdy_amb_array = np.zeros([np.shape(X)[0], np.shape(X)[1], len(plot_times)])

# Pressure gradients for the CO2
dPdx_cur_array = np.zeros([np.shape(X)[0], np.shape(X)[1], len(plot_times)])
dPdy_cur_array = np.zeros([np.shape(X)[0], np.shape(X)[1], len(plot_times)])

# Darcy velocities for the ambient fluid
Ux_amb_array = np.zeros([np.shape(X)[0], np.shape(X)[1], len(plot_times)])
Uy_amb_array = np.zeros([np.shape(X)[0], np.shape(X)[1], len(plot_times)])


# Darcy velocity for the CO2
Ux_cur_array = np.zeros([np.shape(X)[0], np.shape(X)[1], len(plot_times)])
Uy_cur_array = np.zeros([np.shape(X)[0], np.shape(X)[1], len(plot_times)])


# Load data from each of the output times and fill in the corresponding arrays
for i, t in enumerate(plot_times):
    # load height data for this frame
    if i == 0:
        h_array[:, :, i] = np.zeros([np.shape(H0)[0], np.shape(H0)[1]])
    else:
        h_array[:, :, i] = np.loadtxt(
            "./Output/Current_Thickness/h" + "{0:02d}".format(i) + ".txt"
        )

    h_res_array[:, :, i] = np.loadtxt(
        "./Output/Current_Thickness/h_res" + "{0:02d}".format(i) + ".txt"
    )
    P_amb_array[:, :, i] = np.loadtxt(
        "./Output/Current_Pressure/P" + "{0:02d}".format(i) + ".txt"
    )

    P_cur_array[:, :, i] = P_amb_array[:, :, i] + Gamma_val * (
        H0[:, :] + h_array[:, :, i] - np.average(H0[:, :])
    )

    dPdx_amb_array[:, :, i], dPdy_amb_array[:, :, i] = np.gradient(
        P_amb_array[:, :, i], dx, dy
    )

    dPdx_cur_array[:, :, i], dPdy_cur_array[:, :, i] = np.gradient(
        P_cur_array[:, :, i], dx, dy
    )

    Ux_amb_array[:, :, i] = -M * Permeability[:, :] * dPdx_amb_array[:, :, i]
    Uy_amb_array[:, :, i] = -M * Permeability[:, :] * dPdy_amb_array[:, :, i]

    Ux_cur_array[:, :, i] = -Permeability[:, :] * dPdx_cur_array[:, :, i]
    Uy_cur_array[:, :, i] = -Permeability[:, :] * dPdy_cur_array[:, :, i]

    V_active_array[:, :, i] = Porosity * (1.0 - s_a_i) * h_array[:, :, i]
    V_trapped_array[:, :, i] = Porosity * s_c_r * h_res_array[:, :, i]


# Print appropriate maximum and minimum values
max_current_thickness = np.amax(h_array)
print("Maximum active current thickness is  " + str(max_current_thickness))

max_h_res = np.max(h_res_array)
print("Maximum trapped current thickness is " + str(max_h_res))

max_V_active = np.amax(V_active_array)
print("Maximum active volume is             " + str(max_V_active))

max_V_trapped = np.amax(V_trapped_array)
print("Maximum trapped volume is            " + str(max_V_trapped))

max_amb_pressure = np.max(P_amb_array)
print("Maximum ambient pressure is          " + str(max_amb_pressure))
min_amb_pressure = np.min(P_amb_array)
print("Minimum ambient pressure is          " + str(min_amb_pressure))

max_cur_pressure = np.max(P_cur_array)
print("Maximum current pressure is          " + str(max_cur_pressure))
min_cur_pressure = np.min(P_cur_array)
print("Minimum current pressure is          " + str(min_cur_pressure))

max_abs_pressure = np.max(np.abs(P_amb_array))


# Load the volume data recorded at each step, rather than just at the output times
Volume_data = np.loadtxt("./Output/Other/Volumes.txt")
Times = Volume_data[:, 0]
Volumes_active = Volume_data[:, 1]
Volumes_trapped = Volume_data[:, 2]
Volumes_injected = Volume_data[:, 3]
# max_Vol = np.max(Volumes_active)
max_Vol = np.max(Volumes_injected)

Volume_profile_active = np.zeros([len(plot_times)])
Volume_profile_trapped = np.zeros([len(plot_times)])

for i, t in enumerate(plot_times):
    Volume_profile_active[i] = np.sum(V_active_array[:, :, i]) * dx * dy
    Volume_profile_trapped[i] = np.sum(V_trapped_array[:, :, i]) * dx * dy


# Colour maps for the respective plots below
colmap_h = cm.BuPu
colmap_h_res = cm.Reds
colmap_V_active = cm.BuPu  # cm.BuGn
colmap_V_trapped = cm.Reds  # cm.OrRd
colmap_P = cm.seismic

colmap_perm = cm.gray
colmap_poro = cm.gray

# norms for the permeability and porosity (the rest are calculated within the loop below
# as they change between plots)
norm_perm = colors.Normalize(0., np.max(Permeability))
norm_poro = colors.Normalize(0., np.max(Porosity))


# How detailed to make the 3D plot of the current - number of steps between points to plot
stride_val = 1

# Threshold thickness value for masking and bounding contour - used in determining the
# edge of the current
h_threshold = 1e-4
h_res_threshold = 1e-4
V_active_threshold = 1e-4
V_trapped_threshold = 1e-4
P_threshold = 1e-4

# Remaining percentage contours to plot
h_levels = np.array([0.1, 0.2, 0.4, 0.6, 0.8, 0.95]) * max_current_thickness
cont_h_strs = ["10%", "20%", "40%", "60%", "80%", "95%"]

h_res_levels = np.array([0.1, 0.2, 0.4, 0.6, 0.8, 0.95]) * max_h_res
cont_h_res_strs = ["10%", "20%", "40%", "60%", "80%", "95%"]

V_active_levels = np.array([0.1, 0.2, 0.4, 0.6, 0.8, 0.95]) * max_V_active
cont_V_active_strs = ["10%", "20%", "40%", "60%", "80%", "95%"]

V_trapped_levels = np.array([0.1, 0.2, 0.4, 0.6, 0.8, 0.95]) * max_V_trapped
cont_V_trapped_strs = ["10%", "20%", "40%", "60%", "80%", "95%"]

# more levels for the Pressure as it can be negative
P_levels = (
    np.array([-0.95, -0.8, -0.6, -0.4, -0.2, -0.1, 0.0, 0.1, 0.2, 0.4, 0.6, 0.8, 0.95])
    * max_abs_pressure
)
cont_P_strs = [
    "-95%",
    "-80%",
    "-60%",
    "-40%",
    "-20%",
    "-10%",
    "0",
    "10%",
    "20%",
    "40%",
    "60%",
    "80%",
    "95%",
]


# Formatting string for the contour labels
cbar_fmt = lambda x, pos: "{:.3f}".format(x)

# Colours for the bounding contours of the free and trapped CO2 regions
clr_h = "green"
clr_h_res = "tab:brown"


## Main loop over each of the output plots
for i, t in enumerate(plot_times):
    # If there are no contours (because the function is zero everywhere), supress the warning message
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore", message="No contour levels were found within the data range."
        )

        print("Plot " + str(i))

        # load height data for this frame
        h = h_array[:, :, i]
        h_res = h_res_array[:, :, i]
        V_active = V_active_array[:, :, i]
        V_trapped = V_trapped_array[:, :, i]
        P_amb = P_amb_array[:, :, i]
        P_cur = P_cur_array[:, :, i]
        Ux_amb = Ux_amb_array[:, :, i]
        Uy_amb = Uy_amb_array[:, :, i]
        Ux_cur = Ux_cur_array[:, :, i]
        Uy_cur = Uy_cur_array[:, :, i]

        # create colormap according to h value, masked with a threshold value so that it doesn't colour the h=0 regions
        color_dimension_h = np.ma.masked_where(h < h_threshold, h)
        minn, maxx = 0.0, max_current_thickness
        norm_h = colors.Normalize(minn, maxx)
        m = plt.cm.ScalarMappable(norm=norm_h, cmap=colmap_h)
        m.set_array([])
        fcolors_h = m.to_rgba(color_dimension_h)

        # h_res colormap
        color_dimension_h_res = np.ma.masked_where(h_res < h_res_threshold, h_res)
        minn, maxx = 0.0, max_h_res  # color_dimension.max()
        norm_h_res = colors.Normalize(minn, maxx)
        m = plt.cm.ScalarMappable(norm=norm_h_res, cmap=colmap_h_res)
        m.set_array([])
        fcolors_h_res = m.to_rgba(color_dimension_h_res)

        # V_active colormap
        color_dimension_V_active = np.ma.masked_where(
            V_active < V_active_threshold, V_active
        )
        minn, maxx = 0.0, max_V_active
        norm_V_active = colors.Normalize(minn, maxx)
        m = plt.cm.ScalarMappable(norm=norm_V_active, cmap=colmap_V_active)
        m.set_array([])
        fcolors_V_active = m.to_rgba(color_dimension_V_active)

        # V_trapped colormap
        color_dimension_V_trapped = np.ma.masked_where(
            V_trapped < V_trapped_threshold, V_trapped
        )
        minn, maxx = 0.0, max_V_trapped
        norm_V_trapped = colors.Normalize(minn, maxx)
        m = plt.cm.ScalarMappable(norm=norm_V_trapped, cmap=colmap_V_trapped)
        m.set_array([])
        fcolors_V_trapped = m.to_rgba(color_dimension_V_trapped)

        # Ambient Pressure colormap
        color_dimension_P_amb = P_amb
        # minn, maxx = min_pressure, max_pressure
        # minn, maxx = -max_abs_pressure, max_abs_pressure
        minn, maxx = -np.max(np.abs(P_amb)), np.max(np.abs(P_amb))
        norm_P_amb = colors.Normalize(minn, maxx)
        m = plt.cm.ScalarMappable(norm=norm_P_amb, cmap=colmap_P)
        m.set_array([])
        fcolors = m.to_rgba(color_dimension_P_amb)

        # Current Pressure colormap
        color_dimension_P_cur = P_cur
        # minn, maxx = min_pressure, max_pressure
        # minn, maxx = -max_abs_pressure, max_abs_pressure
        minn, maxx = -np.max(np.abs(P_cur)), np.max(np.abs(P_cur))
        norm_P_cur = colors.Normalize(minn, maxx)
        m = plt.cm.ScalarMappable(norm=norm_P_cur, cmap=colmap_P)
        m.set_array([])
        fcolors = m.to_rgba(color_dimension_P_cur)

        fig = plt.figure(figsize=(15, 10))

        gs = GridSpec(3, 3, figure=fig)

        str_title = "[{:02d} of {:02d}]: t = {:3.2e}".format(i, len(plot_times) - 1, t)

        fig.suptitle(
            str_title,
            fontsize=16,
            x=0.01,
            y=0.98,
            horizontalalignment="left",
            verticalalignment="top",
            bbox=dict(facecolor="none", edgecolor="black"),
        )

        ### Porosity ############################################################################
        ax_c = fig.add_subplot(gs[0, 0])

        # surface plot of Porosity
        im_c = ax_c.imshow(
            np.flipud(Porosity),
            cmap=colmap_poro,
            norm=norm_poro,
            extent=[X_grid[0], X_grid[-1], Y_grid[0], Y_grid[-1]],
        )

        # Plot injection locations
        for k in range(0, n_inj_locs):
            ax_c.plot(inj_grid_vals[k, 0], inj_grid_vals[k, 1], "mx")

        ax_c.set_title("Porosity")
        ax_c.set_xlabel(r"$x$", fontsize=20)
        ax_c.set_ylabel(r"$y$", fontsize=20, rotation=0)

        # Add a colourbar to the right of the plot, and make it the same height as the plot
        divider = make_axes_locatable(ax_c)
        cax_c = divider.append_axes("right", size="5%", pad=0.05)

        cbar_poro = plt.colorbar(
            im_c,
            ax=ax_c,
            cmap=colmap_poro,
            norm=norm_poro,
            cax=cax_c,
            format=FuncFormatter(cbar_fmt),
        )

        ### Permeability ########################################################################
        ax_c = fig.add_subplot(gs[1, 0])

        # surface plot of Permeability
        im_c = ax_c.imshow(
            np.flipud(Permeability),
            cmap=colmap_perm,
            norm=norm_perm,
            extent=[X_grid[0], X_grid[-1], Y_grid[0], Y_grid[-1]],
        )

        # Plot injection locations
        for k in range(0, n_inj_locs):
            ax_c.plot(inj_grid_vals[k, 0], inj_grid_vals[k, 1], "mx")

        ax_c.set_title("Permeability")
        ax_c.set_xlabel(r"$x$", fontsize=20)
        ax_c.set_ylabel(r"$y$", fontsize=20, rotation=0)

        # Add a colourbar to the right of the plot, and make it the same height as the plot
        divider = make_axes_locatable(ax_c)
        cax_c = divider.append_axes("right", size="5%", pad=0.05)

        cbar_perm = plt.colorbar(
            im_c,
            ax=ax_c,
            cmap=colmap_perm,
            norm=norm_perm,
            cax=cax_c,
            format=FuncFormatter(cbar_fmt),
        )

        ### Current Thickness - active ##########################################################
        ax_c = fig.add_subplot(gs[0, 1])

        # surface plot of active current thickness
        im_c = ax_c.imshow(
            np.flipud(color_dimension_h),
            cmap=colmap_h,
            norm=norm_h,
            extent=[X_grid[0], X_grid[-1], Y_grid[0], Y_grid[-1]],
        )
        # contours of ceiling topography
        cont_H0 = ax_c.contour(X_grid, Y_grid, H0, colors="gray", alpha=0.25, levels=4)
        # edge contour of active current
        cont_hb = ax_c.contour(
            X_grid,
            Y_grid,
            h * (h >= h_threshold),
            colors=clr_h,
            alpha=1.0,
            levels=[h_threshold],
            linewidths=2,
        )
        # contours of active current thickness
        cont_h = ax_c.contour(
            X_grid,
            Y_grid,
            h * (h >= h_threshold),
            colors="black",
            alpha=0.5,
            levels=h_levels,
        )
        # contour labels
        cont_h_fmt = {}
        for l, s in zip(cont_h.levels, cont_h_strs):
            cont_h_fmt[l] = s
        ax_c.clabel(cont_H0, inline=True, fmt="H0 = %.2g", fontsize=10)
        ax_c.clabel(cont_h, inline=True, fmt=cont_h_fmt, fontsize=10)

        # Plot injection locations
        for k in range(0, n_inj_locs):
            ax_c.plot(inj_grid_vals[k, 0], inj_grid_vals[k, 1], "mx")

        ax_c.set_title("Current Thickness (active)")
        ax_c.set_xlabel(r"$x$", fontsize=20)
        ax_c.set_ylabel(r"$y$", fontsize=20, rotation=0)


        # Add a colourbar to the right of the plot, and make it the same height as the plot
        divider = make_axes_locatable(ax_c)
        cax_c = divider.append_axes("right", size="5%", pad=0.05)

        cbar_ha = plt.colorbar(
            im_c,
            ax=ax_c,
            cmap=colmap_h,
            norm=norm_h,
            cax=cax_c,
            format=FuncFormatter(cbar_fmt),
        )

        ### Current Thickness - trapped ##############################################################
        ax_c = fig.add_subplot(gs[0, 2])

        # surface plot of trapped current thickness
        im_c = ax_c.imshow(
            np.flipud(color_dimension_h_res),
            cmap=colmap_h_res,
            norm=norm_h_res,
            extent=[X_grid[0], X_grid[-1], Y_grid[0], Y_grid[-1]],
        )
        # contours of ceiling topography
        cont_H0 = ax_c.contour(X_grid, Y_grid, H0, colors="gray", alpha=0.25, levels=4)
        # edge contour of trapped current
        cont_hresb = ax_c.contour(
            X_grid,
            Y_grid,
            h_res * (h_res >= h_res_threshold),
            colors=clr_h_res,
            alpha=1.0,
            levels=[h_res_threshold],
            linewidths=2,
        )
        # contours of trapped current thickness
        cont_h_res = ax_c.contour(
            X_grid,
            Y_grid,
            h_res * (h_res >= h_res_threshold),
            colors="black",
            alpha=0.5,
            levels=h_levels,
        )
        # contour labels
        cont_h_res_fmt = {}
        for l, s in zip(cont_h_res.levels, cont_h_res_strs):
            cont_h_res_fmt[l] = s
        ax_c.clabel(cont_H0, inline=True, fmt="H0 = %.2g", fontsize=10)
        ax_c.clabel(cont_h_res, inline=True, fmt=cont_h_res_fmt, fontsize=10)

        # Plot injection locations
        for k in range(0, n_inj_locs):
            ax_c.plot(inj_grid_vals[k, 0], inj_grid_vals[k, 1], "mx")
        
        ax_c.set_title("Current Thickness (trapped)")
        ax_c.set_xlabel(r"$x$", fontsize=20)
        ax_c.set_ylabel(r"$y$", fontsize=20, rotation=0)

        # Add a colourbar to the right of the plot, and make it the same height as the plot
        divider = make_axes_locatable(ax_c)
        cax_c = divider.append_axes("right", size="5%", pad=0.05)

        cbar_ht = plt.colorbar(
            im_c,
            ax=ax_c,
            cmap=colmap_h_res,
            norm=norm_h_res,
            cax=cax_c,
            format=FuncFormatter(cbar_fmt),
        )

        ### Current Volume - active ###################################################################
        ax_c = fig.add_subplot(gs[1, 1])

        # surface plot of active current volume
        im_c = ax_c.imshow(
            np.flipud(color_dimension_V_active),
            cmap=colmap_V_active,
            norm=norm_V_active,
            extent=[X_grid[0], X_grid[-1], Y_grid[0], Y_grid[-1]],
        )
        # contours of ceiling topography
        cont_H0 = ax_c.contour(X_grid, Y_grid, H0, colors="gray", alpha=0.25, levels=4)
        # edge contour of active current
        cont_hb = ax_c.contour(
            X_grid,
            Y_grid,
            h * (h >= h_threshold),
            colors=clr_h,
            alpha=1.0,
            levels=[h_threshold],
            linewidths=2,
        )
        # contours of active current volume
        cont_V_active = ax_c.contour(
            X_grid,
            Y_grid,
            V_active * (h >= h_threshold),
            colors="black",
            alpha=0.5,
            levels=V_active_levels,
        )
        # contour labels
        cont_V_active_fmt = {}
        for l, s in zip(cont_V_active.levels, cont_V_active_strs):
            cont_V_active_fmt[l] = s
        ax_c.clabel(cont_H0, inline=True, fmt="H0 = %.2g", fontsize=10)
        ax_c.clabel(cont_V_active, inline=True, fmt=cont_V_active_fmt, fontsize=10)

        # Plot injection locations
        for k in range(0, n_inj_locs):
            ax_c.plot(inj_grid_vals[k, 0], inj_grid_vals[k, 1], "mx")
        
        ax_c.set_title("Current Volume (active)")
        ax_c.set_xlabel(r"$x$", fontsize=20)
        ax_c.set_ylabel(r"$y$", fontsize=20, rotation=0)

        # Add a colourbar to the right of the plot, and make it the same height as the plot
        divider = make_axes_locatable(ax_c)
        cax_c = divider.append_axes("right", size="5%", pad=0.05)

        cbar_Va = plt.colorbar(
            im_c,
            ax=ax_c,
            cmap=colmap_V_active,
            norm=norm_V_active,
            cax=cax_c,
            format=FuncFormatter(cbar_fmt),
        )

        ### Current Volume - trapped ##############################################################
        ax_c = fig.add_subplot(gs[1, 2])

        # surface plot of trapped current volume
        im_c = ax_c.imshow(
            np.flipud(color_dimension_V_trapped),
            cmap=colmap_V_trapped,
            norm=norm_V_trapped,
            extent=[X_grid[0], X_grid[-1], Y_grid[0], Y_grid[-1]],
        )
        # contours of ceiling topography
        cont_H0 = ax_c.contour(X_grid, Y_grid, H0, colors="gray", alpha=0.25, levels=4)
        # edge contour of trapped current
        cont_hresb = ax_c.contour(
            X_grid,
            Y_grid,
            h_res * (h_res >= h_res_threshold),
            colors=clr_h_res,
            alpha=1.0,
            levels=[h_res_threshold],
            linewidths=2,
        )
        # contours of trapped current volume
        cont_V_trapped = ax_c.contour(
            X_grid,
            Y_grid,
            V_trapped * (h_res >= h_res_threshold),
            colors="black",
            alpha=0.5,
            levels=V_trapped_levels,
        )
        # contour labels
        cont_V_trapped_fmt = {}
        for l, s in zip(cont_V_trapped.levels, cont_V_trapped_strs):
            cont_V_trapped_fmt[l] = s
        ax_c.clabel(cont_H0, inline=True, fmt="H0 = %.2g", fontsize=10)
        ax_c.clabel(cont_V_trapped, inline=True, fmt=cont_V_trapped_fmt, fontsize=10)

        # Plot injection locations
        for k in range(0, n_inj_locs):
            ax_c.plot(inj_grid_vals[k, 0], inj_grid_vals[k, 1], "mx")

        ax_c.set_title("Current Volume (trapped)")
        ax_c.set_xlabel(r"$x$", fontsize=20)
        ax_c.set_ylabel(r"$y$", fontsize=20, rotation=0)

        # Add a colourbar to the right of the plot, and make it the same height as the plot
        divider = make_axes_locatable(ax_c)
        cax_c = divider.append_axes("right", size="5%", pad=0.05)

        cbar_Vt = plt.colorbar(
            im_c,
            ax=ax_c,
            cmap=colmap_V_trapped,
            norm=norm_V_trapped,
            cax=cax_c,
            format=FuncFormatter(cbar_fmt),
        )

        ### Current Pressure #####################################################################
        ax_c = fig.add_subplot(gs[2, 1])

        # surface plot of current pressure
        im_c = ax_c.imshow(
            np.flipud(color_dimension_P_cur),
            cmap=colmap_P,
            norm=norm_P_cur,
            extent=[X_grid[0], X_grid[-1], Y_grid[0], Y_grid[-1]],
        )
        # current Darcy velocity field
        ax_c.quiver(
            X[0:-1:flow_field_step, 0:-1:flow_field_step],
            Y[0:-1:flow_field_step, 0:-1:flow_field_step],
            Uy_cur[0:-1:flow_field_step, 0:-1:flow_field_step],
            Ux_cur[0:-1:flow_field_step, 0:-1:flow_field_step],
        )
        # edge contour of active current
        cont_hb = ax_c.contour(
            X_grid,
            Y_grid,
            h * (h >= h_threshold),
            colors=clr_h,
            alpha=1.0,
            levels=[h_threshold],
            linewidths=2,
        )
        # edge contour of trapped current
        cont_hresb = ax_c.contour(
            X_grid,
            Y_grid,
            h_res * (h_res >= h_res_threshold),
            colors=clr_h_res,
            alpha=1.0,
            levels=[h_res_threshold],
            linewidths=2,
        )

        # Plot injection locations
        for k in range(0, n_inj_locs):
            ax_c.plot(inj_grid_vals[k, 0], inj_grid_vals[k, 1], "mx")

        ax_c.set_title("Current Pressure and Darcy velocity")
        ax_c.set_xlabel(r"$x$", fontsize=20)
        ax_c.set_ylabel(r"$y$", fontsize=20, rotation=0)


        # Add a colourbar to the right of the plot, and make it the same height as the plot
        divider = make_axes_locatable(ax_c)
        cax_c = divider.append_axes("right", size="5%", pad=0.05)

        cbar_P_cur = plt.colorbar(
            im_c,
            ax=ax_c,
            cmap=colmap_P,
            norm=norm_P_cur,
            cax=cax_c,
            format=FuncFormatter(cbar_fmt),
        )

        ### Ambient Pressure #####################################################################
        ax_c = fig.add_subplot(gs[2, 2])

        # surface plot of ambient pressure
        im_c = ax_c.imshow(
            np.flipud(color_dimension_P_amb),
            cmap=colmap_P,
            norm=norm_P_amb,
            extent=[X_grid[0], X_grid[-1], Y_grid[0], Y_grid[-1]],
        )
        # ambient Darcy velocity field
        ax_c.quiver(
            X[0:-1:flow_field_step, 0:-1:flow_field_step],
            Y[0:-1:flow_field_step, 0:-1:flow_field_step],
            Uy_amb[0:-1:flow_field_step, 0:-1:flow_field_step],
            Ux_amb[0:-1:flow_field_step, 0:-1:flow_field_step],
        )
        # edge contour of active current
        cont_hb = ax_c.contour(
            X_grid,
            Y_grid,
            h * (h >= h_threshold),
            colors=clr_h,
            alpha=1.0,
            levels=[h_threshold],
            linewidths=2,
        )
         # edge contour of trapped current
        cont_hresb = ax_c.contour(
            X_grid,
            Y_grid,
            h_res * (h_res >= h_res_threshold),
            colors=clr_h_res,
            alpha=1.0,
            levels=[h_res_threshold],
            linewidths=2,
        )

        # Plot injection locations
        for k in range(0, n_inj_locs):
            ax_c.plot(inj_grid_vals[k, 0], inj_grid_vals[k, 1], "mx")

        ax_c.set_title("Ambient Pressure and Darcy velocity")
        ax_c.set_xlabel(r"$x$", fontsize=20)
        ax_c.set_ylabel(r"$y$", fontsize=20, rotation=0)

        # Add a colourbar to the right of the plot, and make it the same height as the plot
        divider = make_axes_locatable(ax_c)
        cax_c = divider.append_axes("right", size="5%", pad=0.05)

        cbar_P_cur = plt.colorbar(
            im_c,
            ax=ax_c,
            cmap=colmap_P,
            norm=norm_P_amb,
            cax=cax_c,
            format=FuncFormatter(cbar_fmt),
        )

        ### Total Volume ##############################################################################
 
        ax_c = fig.add_subplot(gs[2, 0:1])

        # Total active volume - output times
        ax_c.plot(plot_times, Volume_profile_active, ".", markersize=8, color=clr_h)
        # Total trapped volume - output times
        ax_c.plot(plot_times, Volume_profile_trapped, ".", markersize=8, color=clr_h_res)
        # Total active volume - every step
        ax_c.plot(Times, Volumes_active, "-.", color=clr_h, label="Mobile CO$_{2}$")
        # Total trapped volume - every step
        ax_c.plot(Times, Volumes_trapped, ":", color=clr_h_res, label="Trapped CO$_{2}$")
        # Total CO2 phase - every step
        ax_c.plot(Times, Volumes_active + Volumes_trapped, "k--", label="Total CO$_{2}$ phase")
        # Total CO2 injected - every step
        ax_c.plot(Times, Volumes_injected, "b-", label="Total CO$_{2}$ injected")
        # Current output time for this plot
        ax_c.axvline(x=t, color="gray")

        ax_c.set_title("Volume")
        ax_c.set_xlabel(r"$t$", fontsize=20)
        ax_c.set_ylabel(r"$V$", fontsize=20, labelpad=20, rotation=0)

        ax_c.legend(loc="upper left", fontsize=9)

        #Add a grid to the volume plot
        ax_c.grid(True, linestyle="-", alpha=0.5)

        #Tidy up the layout of subplots
        plt.tight_layout()

        # Save this frame
        plt.savefig("./plots/Overview_plot/temp/t" + "{0:02d}".format(i) + ".png")
        plt.close()
